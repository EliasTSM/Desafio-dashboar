export interface Usuario {
  id?: number | string;
  name?: string;
  senha?: string;
  email?: string;
}
