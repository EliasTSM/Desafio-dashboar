import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lista-menu',
  templateUrl: './lista-menu.component.html',
  styleUrls: ['./lista-menu.component.css']
})
export class ListaMenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
